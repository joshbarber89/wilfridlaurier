package ec;

import java.io.IOException;
import org.jboss.logging.Logger;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ec.weka.WekaStatelessLocal;

/**
 * Servlet implementation class Results
 */
@WebServlet("/Results")
public class Results extends HttpServlet {
	private static final Logger LOGGER = Logger.getLogger(Results.class);
	private static final long serialVersionUID = 1L;
       
	@EJB
    private WekaStatelessLocal lrStateless;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Results() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Make sure all parameters came in.
		if (request.getParameterMap().size() != 11) {
			LOGGER.error("Not enough Params for Prediction");
		} else {
			String age = request.getParameter("age");
			String sex = request.getParameter("sex");
			String chestPainType = request.getParameter("chest-pain-type");
			String restingBP = request.getParameter("resting-bp");
			String cholesterol = request.getParameter("cholesterol");
			String fastingBloodPressure = request.getParameter("fasting-blood-pressure");
			String restingECG = request.getParameter("resting-ecg");
			String maxHR = request.getParameter("max-hr");
			String excerciseAngina = request.getParameter("exercise-angina");
			String oldPeak = request.getParameter("old-peak");
			String stSlope = request.getParameter("st-slope");
			String test = "0";		
					
			String[] allValues = {age,sex,chestPainType,restingBP,cholesterol,fastingBloodPressure,restingECG,maxHR,excerciseAngina,oldPeak,stSlope,test}; 
			try {		
				// Make Prediction and then output JSON
				String result = lrStateless.predict(allValues);
				LOGGER.info("Prediction: " + result);
		        PrintWriter out = response.getWriter();
		        response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        out.print("{\"response\":\"Okay\",\"result\":\""+result+"\"}");
		        out.flush();  
			} catch (Exception e) {
				LOGGER.error("Prediction Errored");
		        PrintWriter out = response.getWriter();
		        response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        out.print("{\"response\":\"Error\"}");
		        out.flush();  
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
