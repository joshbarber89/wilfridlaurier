package ec;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ec.authenticate.AuthenticateLocal;
import ec.weka.WekaStatelessLocal;
import org.jboss.logging.Logger;
/**
 * Servlet implementation class Admin
 */
@WebServlet("/Admin")
public class Admin extends HttpServlet {
	private static final Logger LOGGER = Logger.getLogger(Admin.class);
	private static final long serialVersionUID = 1L;

	@EJB
    private AuthenticateLocal authenticateStateless;
	
	@EJB
    private WekaStatelessLocal lrStateless;
    /**
     * Default constructor. 
     */
    public Admin() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String switchModel = request.getParameter("switchModel");
		
		// Determine if we are just switching the model, or if we are logging in. Two use cases for this controller
		if (switchModel != null && !switchModel.equals("") && authenticateStateless.valid()) {
			// Change Model, then give user link to go back to homepage.
			LOGGER.info("Switching Model");
			switch (switchModel) {
			case "1":
				lrStateless.changeModel(1);
				break;
			case "2":
				lrStateless.changeModel(2);
				break;
			default:
				lrStateless.changeModel(1);
			}
	        response.setContentType("text/html");
	        response.setCharacterEncoding("UTF-8");
			PrintWriter out = response.getWriter();
			String html = "<p>Succesfully changed Model Algorithm</p>"
					+ "<a href='/ec-web/'>Back To Form</a>";
			out.print(html);
			out.flush();		
			
		} else {
			LOGGER.info("User Login Processing");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			boolean valid = authenticateStateless.validate(username, password);
			
			if (valid) {
				// Give options to the admin to change the algorithm.
		        response.setContentType("text/html");
		        response.setCharacterEncoding("UTF-8");
				PrintWriter out = response.getWriter();
				String html = "<form action=\"/ec-web/Admin\" method=\"post\">"
						+ "<label>Linear Progression Algorithm</label>"
						+ "<input type=\"radio\" name=\"switchModel\" value=\"1\" checked/>"
						+ "<br/>"
						+ "<label>Decision Tree Algorithm</label>"
						+ "<input type=\"radio\" name=\"switchModel\" value=\"2\"/>"
						+ "<br/>"
						+ "<input type=\"submit\" value=\"Submit\"/>"
						+ "</form>";
				out.print(html);
				out.flush();
			} else {
				response.sendRedirect("/ec-web/");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
