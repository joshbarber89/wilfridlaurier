package ec;

import java.sql.*;

import weka.classifiers.functions.LinearRegression;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.converters.ConverterUtils.DataSource;

public class LinearRegressionModel {
	
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/test";
	static final String USER = "root";
	static final String PASS = "";

	// Set the initialization of the Linear Regression model and save the data to the database
	public static void main(String[] args) throws Exception {
		// Train instance first
		LinearRegression cls = new LinearRegression();
		
		Instances trainingDataSet = DataSource.read("data/heart.arff");
		
		trainingDataSet.setClassIndex(trainingDataSet.numAttributes()-1);
		
		SelectedTag method = new SelectedTag(LinearRegression.SELECTION_NONE, LinearRegression.TAGS_SELECTION);
		cls.setAttributeSelectionMethod(method); 
		
		cls.buildClassifier(trainingDataSet);
		
		Connection connection = null;
		Statement statement = null;
		String sql;

		try {
			// Save to DB
			Class.forName(JDBC_DRIVER);
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement();

			sql = "INSERT INTO MODEL (name, classname, object) VALUES ('weka-lr', 'weka_regresssion', ?)";
			PreparedStatement ps = (PreparedStatement) connection.prepareStatement(sql);
	
			// set input parameters			
			ps.setObject(1, cls);
			
			ps.executeUpdate();

			ps.close();
			
			System.out.print("Successfully saved!");

		} catch (SQLException e) { // Handle errors for JDBC
			e.printStackTrace();
		} catch (Exception e) { // Handle errors for Class.forName
			e.printStackTrace();
		} finally { // finally block used to close resources
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
}
