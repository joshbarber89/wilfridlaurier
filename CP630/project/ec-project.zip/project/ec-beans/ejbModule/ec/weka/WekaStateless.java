package ec.weka;


import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import ec.authenticate.Authenticate;
import ec.model.Model;
import weka.classifiers.Classifier;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.trees.M5P;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

import org.jboss.logging.Logger;

/**
 * Session Bean implementation class LRStateless
 */
@Stateless
@LocalBean
public class WekaStateless implements WekaStatelessLocal {
	private static final Logger LOGGER = Logger.getLogger(WekaStateless.class);
	
    @EJB
    private Authenticate validation;

	private int currentModel = 1;
	
	
    @PersistenceContext(unitName="primary")
    private EntityManager entityManager;
    
    /**
     * Default constructor. 
     */
    public WekaStateless() {
        // TODO Auto-generated constructor stub
    }
    
    private LinearRegression getLinearRegressionModel() throws Exception {
        List<Model> models = entityManager.createNamedQuery("Model.getRegression", Model.class)
                .getResultList();
        if (models.size() == 1) {
        	Model model = models.get(0);
        	
        	byte[] buf = model.getObject();
	        if (buf != null) { 
	        	try {
    	        	ObjectInputStream objectIn = new ObjectInputStream(new ByteArrayInputStream(buf));    	
    	        	LinearRegression lr = (LinearRegression)  objectIn.readObject();
    	        	LOGGER.info("Linear Regression Model Found");
    	        	return lr;
	        	}
	        	catch (Exception ex) {	        		
	        		return null;
	        	}
	        }        
        }
        LOGGER.error("No Linear Regression Model Found");
    	return null;
    }
    
    private M5P getDecisiontreeModel() throws Exception {
        List<Model> models = entityManager.createNamedQuery("Model.getDecisionTree", Model.class)
                .getResultList();
        if (models.size() == 1) {
        	Model model = models.get(0);
        	
        	byte[] buf = model.getObject();
	        if (buf != null) { 
	        	try {
    	        	ObjectInputStream objectIn = new ObjectInputStream(new ByteArrayInputStream(buf));    	
    	        	M5P dt = (M5P) objectIn.readObject();
    	        	LOGGER.info("Decision Tree Model Found");
    	        	return dt;
	        	}
	        	catch (Exception ex) {	        		
	        		return null;
	        	}
	        }        
        }
        LOGGER.error("No Decision Tree Model Found");
    	return null;
    }
    
	@Override
	public String predict(String[] args) {
		if (this.currentModel == 1) {
			return this.predictLinearRegression(args);
		} else {
			return this.predictDecisionTree(args);
		}		
	}
    
    private String predictLinearRegression(String[] attrs) {    	
    	try {   	
	        ArrayList<Attribute> atts = new ArrayList<Attribute>();
	        
	        Instances data;       
	        
	        double[] vals;       
	    	
	    	for (int i = 0; i < attrs.length; i++) {    		
	    		atts.add(new Attribute("att"+(i+1)));    		
	    	}    	
	    	
	        data=new Instances("LinearRegression",atts,0);
	        
	        vals=new double[data.numAttributes()];
	
	    	for (int i = 0; i < attrs.length; i++) {
	    		String attr = attrs[i];
	    		vals[i] = Double.parseDouble(attr);   		
	    	}     	
	        
	        data.add(new DenseInstance(1,vals));       
	        
	    	Classifier cls = this.getLinearRegressionModel();
	    	
			Instance predicationDataInstance = data.lastInstance();
			double value = cls.classifyInstance(predicationDataInstance);
	    	
			LOGGER.info("Linear Regression Prediction: " + value);		
			return Double.toString(value);
    	} catch (Exception ex) {
    		LOGGER.error("Linear Regression Prediction Failed");
    		return null;
    	}
    	
    }
	private String predictDecisionTree(String[] attrs) {
		try {
	        ArrayList<Attribute> atts = new ArrayList<Attribute>();
	        
	        Instances data;       
	        
	        double[] vals;       
	    	
	    	for (int i = 0; i < attrs.length; i++) {    		
	    		atts.add(new Attribute("att"+(i+1)));    		
	    	}    	
	    	
	        data=new Instances("DecisionTree",atts,0);
	        
	        vals=new double[data.numAttributes()];
	
	    	for (int i = 0; i < attrs.length; i++) {
	    		String attr = attrs[i];
	    		vals[i] = Double.parseDouble(attr);   		
	    	}     	
	        
	        data.add(new DenseInstance(1,vals));       
	        
	    	Classifier cls = this.getDecisiontreeModel();
	    	
			Instance predicationDataInstance = data.lastInstance();
			double value = cls.classifyInstance(predicationDataInstance);
	    	
			LOGGER.info("Decision Tree Prediction: " + value);		
			return Double.toString(value);
    	} catch (Exception ex) {
    		LOGGER.error("Decision Tree Prediction Failed");
    		return null;
    	}
	}



	@Override
	public boolean changeModel(int value) {
		if (validation.role() == 1) {
			if (value > 1) {
				LOGGER.info("Model Changed to Decision Tree");	
				this.currentModel = 2;			
			} else {
				LOGGER.info("Model Changed to Linear Regression");
				this.currentModel = 1;			
			}
			return true;
		}
		LOGGER.info("Model Change Failed");	
		return false;
	}

}
