package ec.weka;

import javax.ejb.Local;

@Local
public interface WekaStatelessLocal {
	// Predict value, in this case heart disease. Will predict on set model (linear regression, decision tree)
	public String predict(String[] args);
	// Changes the model between linear regression and decision tree
	public boolean changeModel(int value);
}
