package ec.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Model")
@NamedQueries({
    @NamedQuery(name = "Model.getDecisionTree", query = "SELECT a FROM Model a WHERE name = 'weka-dt' ORDER BY date DESC"),
    @NamedQuery(name = "Model.getRegression", query = "SELECT a FROM Model a WHERE name = 'weka-lr' ORDER BY date DESC")
})
// The Model table in the DB. Holds structure of model algorithms.
public class Model {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String classname;
    @Lob
    @Column(nullable = false, length = 2097152)
    private byte[] object;
    private String date;
    public Model() { }
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) {  this.name = name; }
    public String getClassname() { return classname; }
    public void setClassname(String classname) {  this.classname = classname; }
    public byte[] getObject() { return this.object; }
    public void setObject(byte[] object) { this.object = object; }
    public String getDate() { return date; }
    public void setDate(String date) {  this.date = date; }
    
    
    @Override
    public String toString() {
        return "Model {" + "id=" + id + ", name='" + name + ", classname=" + classname + ", object=" + object + ", date=" + date + '\'' + '}';
    }
}
