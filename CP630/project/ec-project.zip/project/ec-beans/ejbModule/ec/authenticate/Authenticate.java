package ec.authenticate;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.logging.Logger;

import ec.user.User;

/**
 * Session Bean implementation class Common
 */
@Singleton
@LocalBean
public class Authenticate implements AuthenticateLocal {
	private static final Logger LOGGER = Logger.getLogger(Authenticate.class);

    private User user;
    private Boolean valid = false;
    private Integer role = 3;
    
    @PersistenceContext(unitName="primary")
    private EntityManager entityManager;

    public Authenticate() {}


	@Override
	public Boolean validate(String username, String password) {
        List<User> users = entityManager.createNamedQuery("User.login", User.class)
                .setParameter("name", username)
                .setParameter("password", password)
                .getResultList();
        if (users.size() == 1) {
        	this.user = users.get(0);
        	this.valid = true;
        	this.role = user.getRole(); 
        	LOGGER.info("User " + this.user.getName() + " found");
        	return true;        
        }
        LOGGER.error("No Users Found");
    	return false;
	}

	@Override
	public Boolean valid() {
		if (this.valid) {
			LOGGER.info("User valid");
		} else {
			LOGGER.error("User not valid");
		}
		return this.valid;
	}

	@Override
	public Integer role() {
		return this.role;
	}

	@Override
	public User user() {
		return this.user;
	}

}
