package ec.authenticate;

import javax.ejb.Local;

import ec.user.User;

@Local
public interface AuthenticateLocal {
    // Get User via Username and Password, then set the session variables
    public Boolean validate(String username, String password);
	// Check if user is valid
    public Boolean valid();
	// Check user role
    public Integer role();
	// Check User
    public User user();
}
