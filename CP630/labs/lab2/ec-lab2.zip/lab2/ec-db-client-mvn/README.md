This project is provided as a trouble shooting reference.# Database Connection Project
Author: HBF  
Date: 2020-09-26 (update)  

This is 

- It is used to test EJB session bean part of Lab1 and Lab2. 
- This project is provided as a trouble shooting help.