/*
 * HBF
 */
package ec.db;

import java.io.Serializable;

public class StatsModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private int count = 0;
	private double mean = 0;

	public int getCount() {
		return count;
	}

	public void setCount(int a) {
		count = a;
	}

	public double getMean() {
		return mean;
	}

	public void setMean(double a) {
		mean = a;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("count:" + count + "\n");
		buffer.append("mean:" + mean + "\n");
		return buffer.toString();
	}
}
