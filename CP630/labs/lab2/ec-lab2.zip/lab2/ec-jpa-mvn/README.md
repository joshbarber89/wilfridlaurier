## JMS client Project
Author: HBF  
Date: 2020-09-26 (update)  

This project is for Lab2 Task 4.3 ec-jpa-mvn for standalone JPA program.   

It contains a simple entity User and UserReportory provide managed data persistent operations. It uses MySQL as persistent database. 

This project is provided as a trouble shooting help.

   