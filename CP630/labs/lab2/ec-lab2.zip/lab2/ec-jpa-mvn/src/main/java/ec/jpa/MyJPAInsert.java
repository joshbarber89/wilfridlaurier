package ec.jpa;

import ec.jpa.model.Model;
import ec.jpa.model.User;
import ec.jpa.repository.ModelRepository;
import ec.jpa.repository.UserRepository;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Optional;

public class MyJPAInsert {

    public static void main(String[] args) throws IOException {
        // Create our entity manager
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ec-jpa");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // Create our repositories
        UserRepository userrepository = new UserRepository(entityManager);
        ModelRepository modelrepository = new ModelRepository(entityManager);

        User user = new User("admin");
        User savedUser = userrepository.save(user);
        System.out.println("Saved User: " + savedUser.getName());
//
//        user = new User("me");
//        //user.setId(2);
//        savedUser = userrepository.save(user);
//        System.out.println("Saved User: " + savedUser.get());
//        
        Model model = new Model();
        model.setName("stats");
        StatsModel ssobj = new StatsModel();
		ssobj.setCount(1);
		ssobj.setMean(1);
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		try {
		  out = new ObjectOutputStream(bos);   
		  out.writeObject(ssobj);
		  out.flush();
		  byte[] yourBytes = bos.toByteArray();
		} finally {
		  try {
		    bos.close();
		  } catch (IOException ex) {
		    // ignore close exception
		  }
		}
		
		model.setObject(bos.toByteArray());
		modelrepository.save(model);
		                
        // Close the entity manager and associated factory
        entityManager.close();
        entityManagerFactory.close();
    }
}
