package ec.jpa;

import ec.jpa.model.Model;
import ec.jpa.model.User;
import ec.jpa.repository.ModelRepository;
import ec.jpa.repository.UserRepository;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.Optional;

public class MyJPAFind {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // Create our entity manager
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ec-jpa");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // Create our repositories
        UserRepository userrepository = new UserRepository(entityManager);

        // Find all Users
        List<User> users = userrepository.findAll();
        System.out.println("Users:");
        users.forEach(System.out::println);

        // Find User by name
//        Optional<User> user = userrepository.findByName("admin");
//        System.out.println("Searching for a user by name: ");
//        user.ifPresent(System.out::println);
        
      User user = userrepository.findByName("admin");
      System.out.println("Searching for a user by name: ");
      System.out.println(user.toString());
        
//        
//        // Find User by id
//        user = userrepository.findById(1);
//        System.out.println("Searching for a user by id: ");
//        user.ifPresent(System.out::println);
        
//        ModelRepository ModelRepository = new ModelRepository(entityManager);
//        List<Model> ms = ModelRepository.findAll();
//        System.out.println("Model:");
//        ms.forEach(System.out::println);
//        
//        if (ms.size()> 0 && ms.get(0).getName().equals("stats")) {
//        	byte[] buf = ms.get(0).getObject(); 
//            if (buf != null) {
//            	ObjectInputStream objectIn = new ObjectInputStream(new ByteArrayInputStream(buf));
//            	StatsModel statsmodel = (StatsModel)  objectIn.readObject();
//            	System.out.println(statsmodel.toString());
//            }                    	                    	
//        }
        
                       
        // Close the entity manager and associated factory
        entityManager.close();
        entityManagerFactory.close();
    }
}
