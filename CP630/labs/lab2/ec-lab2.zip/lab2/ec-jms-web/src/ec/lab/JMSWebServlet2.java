package ec.lab;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/servletjms")
public class JMSWebServlet2 extends HttpServlet {
    private static final long serialVersionUID = 1L;
     
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("text/html");        
        PrintWriter out = resp.getWriter();
        Connection connection = null;
        
        try {
        	Properties props = new Properties();
            props.setProperty(Context.INITIAL_CONTEXT_FACTORY,"org.jboss.naming.remote.client.InitialContextFactory");
            props.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming");
            props.setProperty(Context.PROVIDER_URL, "http-remoting://localhost:8080");
            props.put(Context.SECURITY_PRINCIPAL, "quickstartUser");
            props.put(Context.SECURITY_CREDENTIALS, "quickstartPwd1!");
            props.put("jboss.naming.client.ejb.context", true);
            
            Context context = new InitialContext(props);
            ConnectionFactory connectionFactory = (ConnectionFactory) context.lookup("jms/RemoteConnectionFactory");
            connection = connectionFactory.createConnection("quickstartUser", "quickstartPwd1!");
            
            Session session = connection.createSession(false, QueueSession.AUTO_ACKNOWLEDGE);
            Destination queue = (Destination) context.lookup("jms/queue/test");
            connection.start();
           
            MessageProducer producer = session.createProducer(queue);
            
            String httpmessage = req.getParameter("message");
            
            if (httpmessage != null) {
	            Message msg = session.createTextMessage(httpmessage);
	            producer.send(msg);           
	            System.out.println("JMS sent message:"+httpmessage);
	            out.write("JMS sent message:"+httpmessage);
            }
            else {
            	out.write("no message from HTTP client");
            }
            
        } catch (NamingException e) {
			e.printStackTrace();
		} catch (JMSException e) {
			e.printStackTrace();
		} finally {
            if (connection != null) {
                System.out.println("close the connection");
                try {
					connection.close();
				} catch (JMSException e) {
					e.printStackTrace();
				}
            }
        }

    }
}